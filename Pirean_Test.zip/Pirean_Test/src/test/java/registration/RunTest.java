package registration;

/**
 * Created by smita on 29/05/2016.
 */
import org.junit.runner.RunWith;

import cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
@Cucumber.Options(
        format = {"html:target/cucumber"},
    //  tags = {"@travelex, @wiki"})
tags = "@Facebook")
public class RunTest {
}
