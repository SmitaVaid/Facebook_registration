package registration;

/**
 * Created by smita on 29/05/2016.
 */

import cucumber.annotation.After;
import cucumber.annotation.Before;
import cucumber.annotation.en.Given;
import cucumber.annotation.en.Then;
import cucumber.annotation.en.When;
import junit.framework.Assert;
import org.openqa.selenium.WebDriver;

import java.net.MalformedURLException;

public class StepDefs {
    static WebDriver driver;
    RegistrationPage register;


    @Before
   public void StartBrowser() throws MalformedURLException, InterruptedException {
      try {
         BrowserFactory.StartBrowser("Firefox", "https://www.facebook.com/");
          driver = BrowserFactory.driver;
      } catch (Exception e) {
          e.printStackTrace();
      }

        register = new RegistrationPage();

    }
    @Given("^user is on Facebook registration page$")
    public void user_is_on_Facebook_registration_page() {
        Assert.assertTrue(Utils.isTextPresent("Facebook"));
        Assert.assertTrue(Utils.isTextPresent("Create an account"));

    }
    @When("^enter name, surname, email,ReEnterEmail,NewPassword as \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
    public void enter_name_surname_email_ReEnterEmail_NewPassword_as_(String arg1, String arg2, String arg3, String arg4, String arg5) {
        register.RegistrationByEmail(arg1,arg2,arg3,arg4,arg5);
    }


    @When("^select a valid DOB$")
    public void select_a_valid_DOB() {
      register.selectDOB();

    }

    @When("^select a valid gender$")
    public void select_a_valid_gender() {
       register.selectGender();
    }

    @When("^click on \"([^\"]*)\" button$")
    public void click_on_button(String arg1) {
        register.clickCreateAnAccountButton();
        Utils.sleep(5);

    }

    @Then("^user should get a mesage \"([^\"]*)\"$")
    public void user_should_get_a_mesage(String arg1) {
       Assert.assertTrue(Utils.isTextPresent(arg1));
    }

    @Then("^user should navigate to FB home page$")
    public void user_should_navigate_to_FB_home_page() {

    }

    @When("^User enters \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
    public void User_enters_(String arg1, String arg2, String arg3, String arg4, String arg5) {
      register.RegistrationByEmail(arg1,arg2,arg3,arg4,arg5);
    }

    @When("^select a DOB$")
    public void select_a_DOB() {
        register.selectDOB();

    }

    @When("^select a gender$")
    public void select_a_gender() {
        register.selectGender();

    }

    @Then("^\"([^\"]*)\" should be displayed$")
    public void should_be_displayed(String ErrorMessage) {
        register.verifyErrorMessage(ErrorMessage);

    }

    @After
       public void stop()
      {
       driver.quit();

      }

}
