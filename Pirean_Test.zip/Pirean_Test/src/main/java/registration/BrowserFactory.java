package registration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

/**
 * Created by smita on 29/05/2016.
 */
public abstract class BrowserFactory {
    public static WebDriver driver;

    public static WebDriver StartBrowser(String Browser, String URL){
        try
        {
        if (Browser.equals("Firefox")) {
            driver = new FirefoxDriver();


        }
         else if (Browser.equals("Chrome"))

        {

            driver = new ChromeDriver();

        } else if (Browser.equals("IE"))

        {

            driver = new InternetExplorerDriver();

        }

        else
            throw new RuntimeException("Browser give "+Browser+ " did not load..");
        }
        catch(Exception e)
        {
            throw new RuntimeException("Browser give "+Browser+ " did not load..");
        }
        driver.get(URL);
        driver.manage().window().maximize();
        return driver;
    }

    public static WebDriver getDriver()
    {
        return driver;
    }

}