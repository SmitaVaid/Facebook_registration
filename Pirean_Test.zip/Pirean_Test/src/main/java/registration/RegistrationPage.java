package registration;

import junit.framework.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by smita on 29/05/2016.
 */
public class RegistrationPage {
    WebDriver driver = BrowserFactory.getDriver();

    public void RegistrationByEmail(String name, String surname, String Email, String ReEnterEmail, String NewPassword) {
        driver.findElement(By.name("firstname")).sendKeys(name);
        driver.findElement(By.name("lastname")).sendKeys(surname);
        driver.findElement(By.name("reg_email__")).sendKeys(Email);
        driver.findElement(By.name("reg_email_confirmation__")).sendKeys(ReEnterEmail);
        driver.findElement(By.name("reg_passwd__")).sendKeys(NewPassword);
    }

    public void selectDOB() {
        Utils.selectFromDropDown1(By.id("day"), 5);
        Utils.selectFromDropDown1(By.id("month"), 5);
        Utils.selectFromDropDown1(By.id("year"), 18);
    }

    public void selectGender(){
        Utils.selectCheckBox(By.name("sex"),true);
    }

    public void clickCreateAnAccountButton() {
        driver.findElement(By.name("websubmit")).click();
        Utils.sleep(5);
    }

    public void verifyErrorMessage(String  ErrorMessage) {
        Assert.assertTrue(Utils.isTextPresent(ErrorMessage));

    }
}
